-- 1️⃣ Drop existing table to avoid conflicts
DROP TABLE IF EXISTS retail_sales;

-- 2️⃣ Create new table with the full structure
CREATE TABLE retail_sales (
    row_id INTEGER,
    order_id TEXT,
    order_date DATE,
    ship_date DATE,
    ship_mode TEXT,
    customer_id TEXT,
    customer_name TEXT,
    segment TEXT,
    country TEXT,
    city TEXT,
    state TEXT,
    postal_code TEXT,
    region TEXT,
    sales_person TEXT,
    product_id TEXT,
    category TEXT,
    sub_category TEXT,
    product_name TEXT,
    returned TEXT,
    sales NUMERIC,
    quantity INTEGER,
    discount NUMERIC,
    profit NUMERIC
);

-- 3️⃣ Import your CSV file
COPY retail_sales(row_id, order_id, order_date, ship_date, ship_mode, customer_id, customer_name, segment, country, city, state, postal_code, region, sales_person, product_id, category, sub_category, product_name, returned, sales, quantity, discount, profit)
FROM 'C:/PostgreSQLFiles/Retail-Supply-Chain-Sales-Dataset.csv'
DELIMITER ','
CSV HEADER
ENCODING 'WIN1252';


-- 4️⃣ OPTIONAL: Validate for NULL or Missing Data
SELECT *
FROM retail_sales
WHERE order_id IS NULL
   OR product_id IS NULL
   OR category IS NULL
   OR sub_category IS NULL
   OR sales IS NULL
   OR profit IS NULL;

-- 5️⃣ OPTIONAL: Remove records with critical missing values
DELETE FROM retail_sales
WHERE order_id IS NULL
   OR product_id IS NULL
   OR category IS NULL
   OR sub_category IS NULL
   OR sales IS NULL
   OR profit IS NULL;

-- 6️⃣ Calculate Profit Margin by Category & Sub-Category
SELECT 
    category,
    sub_category,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    ROUND((SUM(profit) / NULLIF(SUM(sales), 0)) * 100, 2) AS profit_margin_percentage
FROM 
    retail_sales
GROUP BY 
    category, sub_category
ORDER BY 
    profit_margin_percentage DESC;

-- 5️⃣ Top 5 Most Profitable Products
CREATE OR REPLACE VIEW top_profitable_products AS
SELECT 
    product_name,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    ROUND((SUM(profit) / NULLIF(SUM(sales), 0)) * 100, 2) AS profit_margin_percentage
FROM 
    retail_sales
GROUP BY 
    product_name
ORDER BY 
    total_profit DESC
LIMIT 5;

-- 6️⃣ Returned Products Impact
CREATE OR REPLACE VIEW returned_products_analysis AS
SELECT 
    returned,
    COUNT(*) AS total_orders,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    ROUND((SUM(profit) / NULLIF(SUM(sales), 0)) * 100, 2) AS profit_margin_percentage
FROM 
    retail_sales
GROUP BY 
    returned;

-- 7️⃣ Yearly Profit Trend
CREATE OR REPLACE VIEW yearly_profit_trend AS
SELECT 
    EXTRACT(YEAR FROM order_date) AS order_year,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    ROUND((SUM(profit) / NULLIF(SUM(sales), 0)) * 100, 2) AS profit_margin_percentage
FROM 
    retail_sales
GROUP BY 
    order_year
ORDER BY 
    order_year;

-- 8️⃣ High Discount vs. Profit Relationship
CREATE OR REPLACE VIEW discount_vs_profit AS
SELECT 
    discount,
    ROUND(AVG(profit), 2) AS avg_profit_per_discount
FROM 
    retail_sales
GROUP BY 
    discount
ORDER BY 
    discount; 
